<?php
require_once __DIR__ . '/../config.php';
$token = $_SESSION['admin_token'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? '';
    $status = $_POST['status'] ?? '';
    if ($id && $status) {
        supabase_request("appointments?id=eq.$id", 'PATCH', ['status' => $status], $token);
    }
    header('Location: appointments.php?' . http_build_query($_GET)); exit;
}

$month = $_GET['month'] ?? date('Y-m');
$search = $_GET['search'] ?? '';
$start = $month . '-01';
$end = date('Y-m-t', strtotime($start));

$url = "appointments?select=*,services(title)&appointment_date=gte.$start&appointment_date=lte.$end&order=appointment_date.desc,appointment_time.asc";
$appointmentsRes = supabase_request($url, 'GET', null, $token);
$appointments = $appointmentsRes['data'] ?? [];

if ($search) {
    $appointments = array_filter($appointments, fn($a) => stripos($a['customer_name'], $search) !== false || stripos($a['barber_name'] ?? '', $search) !== false);
}

$statusLabels = ['pending' => 'Pendente', 'confirmed' => 'Confirmado', 'completed' => 'Concluído', 'cancelled' => 'Cancelado'];
$statusClasses = ['pending' => 'status-pending', 'confirmed' => 'status-confirmed', 'completed' => 'status-completed', 'cancelled' => 'status-cancelled'];

$prevMonth = date('Y-m', strtotime($start . ' -1 month'));
$nextMonth = date('Y-m', strtotime($start . ' +1 month'));
$monthNames = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
$monthLabel = $monthNames[(int)date('n', strtotime($start)) - 1] . ' ' . date('Y', strtotime($start));

require 'includes/admin_header.php';
?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;flex-wrap:wrap;gap:0.75rem;">
  <h2 style="font-size:1.125rem;font-weight:700;">Agendamentos</h2>
</div>

<div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;margin-bottom:1rem;">
  <div style="display:flex;align-items:center;gap:0.5rem;">
    <a href="?month=<?= $prevMonth ?>&search=<?= urlencode($search) ?>" class="btn-ghost" style="padding:0.5rem;">◀</a>
    <span style="font-size:0.875rem;font-weight:600;min-width:8.75rem;text-align:center;text-transform:capitalize;"><?= $monthLabel ?></span>
    <a href="?month=<?= $nextMonth ?>&search=<?= urlencode($search) ?>" class="btn-ghost" style="padding:0.5rem;">▶</a>
  </div>
  <form method="get" style="flex:1;max-width:15rem;">
    <input type="hidden" name="month" value="<?= htmlspecialchars($month) ?>">
    <input type="text" name="search" class="glass-input" style="font-size:0.8125rem;" placeholder="Buscar por nome..." value="<?= htmlspecialchars($search) ?>">
  </form>
</div>

<?php foreach ($appointments as $a): $st = $a['status'] ?? 'pending'; ?>
<div class="glass-card" style="padding:1rem;margin-bottom:0.5rem;">
  <div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;">
    <div style="flex:1;min-width:0;">
      <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;">
        <span style="font-size:0.875rem;font-weight:600;"><?= htmlspecialchars($a['customer_name']) ?></span>
        <span class="badge <?= $statusClasses[$st] ?? 'status-pending' ?>"><?= $statusLabels[$st] ?? $st ?></span>
      </div>
      <div style="display:flex;align-items:center;gap:0.75rem;margin-top:0.25rem;font-size:0.75rem;color:var(--muted-foreground);flex-wrap:wrap;">
        <span>📅 <?= date('d/m/Y', strtotime($a['appointment_date'])) ?></span>
        <span>🕐 <?= substr($a['appointment_time'], 0, 5) ?></span>
        <?php if (!empty($a['services']['title'])): ?><span><?= htmlspecialchars($a['services']['title']) ?></span><?php endif; ?>
        <?php if (!empty($a['barber_name'])): ?><span>• <?= htmlspecialchars($a['barber_name']) ?></span><?php endif; ?>
      </div>
    </div>
    <?php if ($a['total_price']): ?>
      <span style="font-size:0.875rem;font-weight:700;color:hsl(245,60%,70%);flex-shrink:0;">R$ <?= number_format($a['total_price'], 2, ',', '.') ?></span>
    <?php endif; ?>
    <div style="display:flex;gap:0.25rem;flex-shrink:0;">
      <?php if ($st !== 'completed'): ?>
        <form method="post" style="display:inline;"><input type="hidden" name="id" value="<?= $a['id'] ?>"><input type="hidden" name="status" value="completed"><button type="submit" style="padding:0.5rem;border-radius:0.5rem;background:hsl(160,60%,45%,0.1);border:none;cursor:pointer;color:hsl(160,60%,55%);">✓</button></form>
      <?php endif; ?>
      <?php if ($st !== 'cancelled'): ?>
        <form method="post" style="display:inline;"><input type="hidden" name="id" value="<?= $a['id'] ?>"><input type="hidden" name="status" value="cancelled"><button type="submit" style="padding:0.5rem;border-radius:0.5rem;background:hsl(0,60%,50%,0.1);border:none;cursor:pointer;color:hsl(0,60%,55%);">✕</button></form>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($appointments)): ?>
<div class="glass-card" style="padding:2rem;text-align:center;"><p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum agendamento encontrado</p></div>
<?php endif; ?>
<?php require 'includes/admin_footer.php'; ?>
