<?php
require_once __DIR__ . '/../config.php';
$token = $_SESSION['admin_token'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $payload = [
            'title' => $_POST['title'] ?? '',
            'subtitle' => $_POST['subtitle'] ?: null,
            'price' => (float)($_POST['price'] ?? 0),
            'duration' => $_POST['duration'] ?? '',
            'image_url' => $_POST['image_url'] ?: null,
            'active' => isset($_POST['active']),
            'sort_order' => (int)($_POST['sort_order'] ?? 0),
        ];
        $id = $_POST['id'] ?? '';
        if ($id) {
            supabase_request("services?id=eq.$id", 'PATCH', $payload, $token);
        } else {
            supabase_request('services', 'POST', $payload, $token);
        }
        header('Location: services.php'); exit;
    }
    if ($action === 'delete') {
        $id = $_POST['id'] ?? '';
        supabase_request("services?id=eq.$id", 'DELETE', null, $token);
        header('Location: services.php'); exit;
    }
}

$servicesRes = supabase_request('services?order=sort_order', 'GET', null, $token);
$services = $servicesRes['data'] ?? [];
require 'includes/admin_header.php';
?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
  <h2 style="font-size:1.125rem;font-weight:700;">Serviços</h2>
  <button class="btn-accent" onclick="openModal('serviceModal')" style="font-size:0.75rem;">➕ Novo Serviço</button>
</div>

<?php foreach ($services as $s): ?>
<div class="glass-card list-item">
  <?php if (!empty($s['image_url']) && !str_starts_with($s['image_url'], 'stock://')): ?>
    <img src="<?= htmlspecialchars($s['image_url']) ?>" class="list-thumb">
  <?php else: ?>
    <div class="list-thumb-placeholder">✂</div>
  <?php endif; ?>
  <div class="list-info">
    <div style="display:flex;align-items:center;gap:0.5rem;">
      <span class="list-title"><?= htmlspecialchars($s['title']) ?></span>
      <?php if (!$s['active']): ?><span class="badge badge-inactive">Inativo</span><?php endif; ?>
    </div>
    <div class="list-sub"><?= htmlspecialchars($s['subtitle'] ?? '') ?></div>
    <div style="display:flex;align-items:center;gap:0.75rem;margin-top:0.25rem;">
      <span class="list-price">R$ <?= number_format($s['price'], 2, ',', '.') ?></span>
      <span style="font-size:0.75rem;color:var(--muted-foreground);"><?= htmlspecialchars($s['duration']) ?></span>
    </div>
  </div>
  <div class="list-actions">
    <button class="btn-edit" onclick="editService(<?= htmlspecialchars(json_encode($s)) ?>)">✏</button>
    <form method="post" style="display:inline;" onsubmit="return confirm('Excluir?');">
      <input type="hidden" name="action" value="delete">
      <input type="hidden" name="id" value="<?= $s['id'] ?>">
      <button type="submit" class="btn-delete">🗑</button>
    </form>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($services)): ?>
<div class="glass-card" style="padding:2rem;text-align:center;"><p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum serviço cadastrado</p></div>
<?php endif; ?>

<!-- Modal -->
<div class="modal-overlay" id="serviceModal" style="display:none;">
  <div class="glass-card-strong modal-content">
    <div class="modal-header">
      <h3 id="serviceModalTitle">Novo Serviço</h3>
      <button class="modal-close" onclick="closeModal('serviceModal')">✕</button>
    </div>
    <form method="post">
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="svc_id">
      <div class="form-group"><label class="form-label">Nome *</label><input class="glass-input" name="title" id="svc_title" required placeholder="Ex: Corte Masculino"></div>
      <div class="form-group"><label class="form-label">Descrição</label><input class="glass-input" name="subtitle" id="svc_subtitle" placeholder="Descrição"></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Preço (R$) *</label><input class="glass-input" name="price" id="svc_price" type="number" step="0.01" min="0" required></div>
        <div class="form-group"><label class="form-label">Duração *</label><input class="glass-input" name="duration" id="svc_duration" required placeholder="Ex: 40 min"></div>
      </div>
      <div class="form-group"><label class="form-label">URL da Imagem</label><input class="glass-input" name="image_url" id="svc_image" placeholder="https://..."></div>
      <div class="form-group"><label class="form-label">Ordem</label><input class="glass-input" name="sort_order" id="svc_order" type="number" value="0"></div>
      <div class="form-group" style="display:flex;align-items:center;gap:0.75rem;">
        <label class="form-label" style="margin:0;">Ativo</label>
        <input type="checkbox" name="active" id="svc_active" checked>
      </div>
      <button type="submit" class="btn-accent" style="width:100%;justify-content:center;">💾 Salvar</button>
    </form>
  </div>
</div>

<script>
function editService(s) {
  document.getElementById('serviceModalTitle').textContent = 'Editar Serviço';
  document.getElementById('svc_id').value = s.id;
  document.getElementById('svc_title').value = s.title;
  document.getElementById('svc_subtitle').value = s.subtitle || '';
  document.getElementById('svc_price').value = s.price;
  document.getElementById('svc_duration').value = s.duration;
  document.getElementById('svc_image').value = s.image_url || '';
  document.getElementById('svc_order').value = s.sort_order || 0;
  document.getElementById('svc_active').checked = s.active;
  openModal('serviceModal');
}
</script>
<?php require 'includes/admin_footer.php'; ?>