<?php
require_once __DIR__ . '/../config.php';
$token = $_SESSION['admin_token'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $discountType = $_POST['discount_type'] ?? 'percent';
        $payload = [
            'code' => strtoupper($_POST['code'] ?? ''),
            'discount_percent' => $discountType === 'percent' ? (float)($_POST['discount'] ?? 0) : null,
            'discount_value' => $discountType === 'value' ? (float)($_POST['discount'] ?? 0) : null,
            'active' => isset($_POST['active']),
            'expires_at' => !empty($_POST['expires_at']) ? date('c', strtotime($_POST['expires_at'])) : null,
            'max_uses' => (int)($_POST['max_uses'] ?? 0) ?: null,
        ];
        $id = $_POST['id'] ?? '';
        if ($id) supabase_request("coupons?id=eq.$id", 'PATCH', $payload, $token);
        else supabase_request('coupons', 'POST', $payload, $token);
        header('Location: coupons.php'); exit;
    }
    if ($action === 'delete') { supabase_request("coupons?id=eq.{$_POST['id']}", 'DELETE', null, $token); header('Location: coupons.php'); exit; }
}
$coupons = (supabase_request('coupons?order=created_at.desc', 'GET', null, $token))['data'] ?? [];
require 'includes/admin_header.php';
?>
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
  <h2 style="font-size:1.125rem;font-weight:700;">Cupons</h2>
  <button class="btn-accent" onclick="openModal('couponModal')" style="font-size:0.75rem;">➕ Novo Cupom</button>
</div>
<?php foreach ($coupons as $c): ?>
<div class="glass-card list-item">
  <div class="list-thumb-placeholder" style="background:hsl(245,60%,55%,0.12);color:hsl(245,60%,65%);">🏷</div>
  <div class="list-info">
    <div style="display:flex;align-items:center;gap:0.5rem;">
      <span class="list-title" style="letter-spacing:0.1em;"><?= htmlspecialchars($c['code']) ?></span>
      <?php if (!($c['active'] ?? true)): ?><span class="badge badge-inactive">Inativo</span><?php endif; ?>
    </div>
    <div style="display:flex;align-items:center;gap:0.75rem;margin-top:0.125rem;font-size:0.75rem;color:var(--muted-foreground);">
      <span style="font-weight:600;color:hsl(160,60%,55%);"><?= $c['discount_percent'] ? intval($c['discount_percent']) . '% off' : 'R$ ' . number_format($c['discount_value'] ?? 0, 2, ',', '.') . ' off' ?></span>
      <?php if ($c['max_uses']): ?><span><?= $c['current_uses'] ?? 0 ?>/<?= $c['max_uses'] ?> usos</span><?php endif; ?>
      <?php if ($c['expires_at']): ?><span>Exp: <?= date('d/m/Y', strtotime($c['expires_at'])) ?></span><?php endif; ?>
    </div>
  </div>
  <div class="list-actions">
    <button class="btn-edit" onclick="editCoupon(<?= htmlspecialchars(json_encode($c)) ?>)">✏</button>
    <form method="post" style="display:inline;" onsubmit="return confirm('Excluir?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $c['id'] ?>"><button type="submit" class="btn-delete">🗑</button></form>
  </div>
</div>
<?php endforeach; ?>
<?php if (empty($coupons)): ?><div class="glass-card" style="padding:2rem;text-align:center;"><p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum cupom cadastrado</p></div><?php endif; ?>

<div class="modal-overlay" id="couponModal" style="display:none;">
  <div class="glass-card-strong modal-content">
    <div class="modal-header"><h3 id="couponModalTitle">Novo Cupom</h3><button class="modal-close" onclick="closeModal('couponModal')">✕</button></div>
    <form method="post">
      <input type="hidden" name="action" value="save"><input type="hidden" name="id" id="c_id">
      <div class="form-group"><label class="form-label">Código *</label><input class="glass-input" name="code" id="c_code" required style="text-transform:uppercase;"></div>
      <div class="form-group"><label class="form-label">Tipo</label>
        <select class="glass-input" name="discount_type" id="c_type"><option value="percent">Porcentagem (%)</option><option value="value">Valor Fixo (R$)</option></select>
      </div>
      <div class="form-group"><label class="form-label">Desconto</label><input class="glass-input" name="discount" id="c_discount" type="number" step="0.01" min="0"></div>
      <div class="grid-2">
        <div class="form-group"><label class="form-label">Validade</label><input class="glass-input" name="expires_at" id="c_expires" type="date"></div>
        <div class="form-group"><label class="form-label">Limite de Usos</label><input class="glass-input" name="max_uses" id="c_max" type="number" min="0"></div>
      </div>
      <div class="form-group" style="display:flex;align-items:center;gap:0.75rem;"><label class="form-label" style="margin:0;">Ativo</label><input type="checkbox" name="active" id="c_active" checked></div>
      <button type="submit" class="btn-accent" style="width:100%;justify-content:center;">💾 Salvar</button>
    </form>
  </div>
</div>
<script>
function editCoupon(c) {
  document.getElementById('couponModalTitle').textContent = 'Editar Cupom';
  document.getElementById('c_id').value = c.id;
  document.getElementById('c_code').value = c.code;
  document.getElementById('c_type').value = c.discount_percent ? 'percent' : 'value';
  document.getElementById('c_discount').value = c.discount_percent || c.discount_value || 0;
  document.getElementById('c_expires').value = c.expires_at ? c.expires_at.substring(0, 10) : '';
  document.getElementById('c_max').value = c.max_uses || 0;
  document.getElementById('c_active').checked = c.active;
  openModal('couponModal');
}
</script>
<?php require 'includes/admin_footer.php'; ?>