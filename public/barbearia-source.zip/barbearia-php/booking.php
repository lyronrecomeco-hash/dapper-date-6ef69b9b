<?php
require_once 'config.php';
$settings = get_settings();
$businessName = $settings['business_name'] ?? 'Barbearia';
$serviceId = $_GET['service_id'] ?? '';
$svc = null;
if ($serviceId) {
    $r = supabase_request("services?id=eq.$serviceId&limit=1");
    $svc = $r['data'][0] ?? null;
}
if (!$svc) { header('Location: index.php'); exit; }

$barbersRes = supabase_request('barbers?active=eq.true&order=sort_order');
$barbers = $barbersRes['data'] ?? [];

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $barber = $_POST['barber'] ?? '';
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';

    if ($name && $phone && $date && $time) {
        $payload = [
            'service_id' => $svc['id'],
            'customer_name' => $name,
            'customer_phone' => $phone,
            'barber_name' => $barber,
            'appointment_date' => $date,
            'appointment_time' => $time,
            'total_price' => $svc['price'],
            'status' => 'pending',
        ];
        $result = supabase_request('appointments', 'POST', $payload);
        if ($result['status'] < 300) {
            $whatsapp = $settings['whatsapp_number'] ?? '5511999999999';
            $dateF = date('d/m/Y', strtotime($date));
            $msg = "Olá! Gostaria de confirmar meu agendamento:%0A%0A📋 *Serviço:* {$svc['title']}%0A💈 *Barbeiro:* $barber%0A📅 *Data:* $dateF%0A🕐 *Horário:* $time%0A👤 *Nome:* $name%0A📱 *Telefone:* $phone%0A💰 *Valor:* R$ " . number_format($svc['price'], 2, ',', '.');
            $message = '<div class="glass-card" style="padding:1.5rem;text-align:center;margin-bottom:1rem;border-color:hsl(160,60%,45%,0.3);">
              <p style="font-size:1.5rem;margin-bottom:0.5rem;">✅</p>
              <p style="font-weight:700;color:var(--foreground);">Agendamento realizado!</p>
              <p style="font-size:0.875rem;color:var(--muted-foreground);margin-top:0.25rem;">Enviando para o WhatsApp...</p>
              <a href="https://wa.me/' . $whatsapp . '?text=' . $msg . '" target="_blank" class="btn-accent" style="margin-top:1rem;display:inline-flex;">📱 Confirmar no WhatsApp</a>
            </div>';
        } else {
            $message = '<div class="glass-card" style="padding:1rem;text-align:center;border-color:hsl(0,60%,50%,0.3);margin-bottom:1rem;"><p style="color:hsl(0,60%,60%);">Erro ao agendar. Tente novamente.</p></div>';
        }
    }
}
?>
<?php require 'includes/header.php'; ?>
<main class="container" style="padding:2rem 1rem;">
  <a href="index.php" class="btn-ghost" style="margin-bottom:1rem;display:inline-flex;">← Voltar</a>
  <h2 style="font-size:1.25rem;font-weight:700;margin-bottom:1.5rem;">Agendamento</h2>
  <?= $message ?>
  <div class="glass-card" style="padding:1rem;display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;">
    <div style="flex:1;">
      <div class="service-title"><?= htmlspecialchars($svc['title']) ?></div>
      <div class="service-subtitle"><?= htmlspecialchars($svc['subtitle'] ?? '') ?></div>
      <div style="display:flex;align-items:center;gap:1rem;margin-top:0.5rem;">
        <span class="gold-text" style="font-size:1.125rem;font-weight:700;">R$ <?= number_format($svc['price'], 2, ',', '.') ?></span>
        <span style="font-size:0.75rem;color:var(--muted-foreground);">🕐 <?= htmlspecialchars($svc['duration']) ?></span>
      </div>
    </div>
  </div>

  <form method="post" class="space-y-4">
    <div class="form-group">
      <label class="form-label">Barbeiro</label>
      <select name="barber" class="glass-input">
        <option value="">Selecione...</option>
        <?php foreach ($barbers as $b): ?>
          <option value="<?= htmlspecialchars($b['name']) ?>"><?= htmlspecialchars($b['name']) ?> - <?= htmlspecialchars($b['specialty'] ?? 'Barbeiro') ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="grid-2">
      <div class="form-group">
        <label class="form-label">Data</label>
        <input type="date" name="date" class="glass-input" required min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Horário</label>
        <select name="time" class="glass-input" required>
          <?php
          $opening = $settings['opening_time'] ?? '09:00';
          $closing = $settings['closing_time'] ?? '19:00';
          $lunchStart = $settings['lunch_start'] ?? '12:00';
          $lunchEnd = $settings['lunch_end'] ?? '13:00';
          $t = strtotime($opening);
          $end = strtotime($closing);
          $ls = strtotime($lunchStart);
          $le = strtotime($lunchEnd);
          while ($t < $end) {
            if ($t < $ls || $t >= $le) {
              $timeStr = date('H:i', $t);
              echo "<option value="$timeStr">$timeStr</option>";
            }
            $t += 1800;
          }
          ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="form-label">Seu nome</label>
      <input type="text" name="name" class="glass-input" placeholder="Digite seu nome" required>
    </div>
    <div class="form-group">
      <label class="form-label">WhatsApp</label>
      <input type="tel" name="phone" class="glass-input" placeholder="(11) 99999-9999" required>
    </div>
    <button type="submit" class="btn-accent" style="width:100%;justify-content:center;padding:0.875rem;">📱 Confirmar & WhatsApp</button>
  </form>
</main>
<?php require 'includes/footer.php'; ?>