<?php
require_once 'config.php';
$settings = get_settings();
$businessName = $settings['business_name'] ?? 'Barbearia';

$servicesResult = supabase_request('services?active=eq.true&order=sort_order');
$services = $servicesResult['data'] ?? [];

$productsResult = supabase_request('products?active=eq.true&order=sort_order');
$products = $productsResult['data'] ?? [];

$storeEnabled = ($settings['store_enabled'] ?? '') === 'true';

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? 'all';
$tab = $_GET['tab'] ?? 'services';

// Filter services by category
$filtered = array_filter($services, function($s) use ($search, $category) {
    $matchSearch = !$search || stripos($s['title'], $search) !== false || stripos($s['subtitle'] ?? '', $search) !== false;
    if (!$matchSearch) return false;
    if ($category === 'all') return true;
    $lower = mb_strtolower($s['title']);
    $subtitle = mb_strtolower($s['subtitle'] ?? '');
    $combined = $lower . ' ' . $subtitle;
    switch ($category) {
        case 'cabelo':
            return preg_match('/(corte|degradê|degrade|cabelo|tesoura|máquina|maquina|social|americano|mullet|navalhado)/i', $combined);
        case 'barba':
            return preg_match('/(barba|barboterapia|bigode|aparar)/i', $combined) && !preg_match('/(combo|corte.*barba|barba.*corte)/i', $combined);
        case 'combo':
            return preg_match('/(combo|noivo|corte.*barba|barba.*corte)/i', $combined);
        case 'extras':
            $isCabelo = preg_match('/(corte|degradê|degrade|cabelo|tesoura|máquina|maquina|social|americano|mullet|navalhado)/i', $combined);
            $isBarba = preg_match('/(barba|barboterapia|bigode|aparar)/i', $combined);
            $isCombo = preg_match('/(combo|noivo|corte.*barba|barba.*corte)/i', $combined);
            return !$isCabelo && !$isBarba && !$isCombo;
        default:
            return true;
    }
});

// Date formatting without strftime
$monthNames = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
$days = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
$weekdayPt = $days[(int)date('w')];
$dateStr = date('j') . ' de ' . $monthNames[(int)date('n') - 1];
?>
<?php require 'includes/header.php'; ?>
<main class="container" style="padding-top:1.5rem;padding-bottom:2rem;">
  <div class="mb-6">
    <h2 style="font-size:1.5rem;font-weight:800;letter-spacing:-0.025em;">Olá, seja bem vindo!</h2>
    <p style="font-size:0.875rem;color:var(--muted-foreground);margin-top:0.25rem;"><?= $weekdayPt ?>, <?= $dateStr ?></p>
  </div>

  <?php if ($storeEnabled): ?>
  <div class="tab-bar">
    <a href="?tab=services" class="tab-btn <?= $tab === 'services' ? 'active' : '' ?>">✂ Agendar</a>
    <a href="?tab=store" class="tab-btn <?= $tab === 'store' ? 'active' : '' ?>">🛍 Loja</a>
  </div>
  <?php endif; ?>

  <div class="search-wrap">
    <span class="search-icon">🔍</span>
    <form method="get">
      <input type="hidden" name="tab" value="<?= htmlspecialchars($tab) ?>">
      <input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
      <input type="text" name="search" class="glass-input" style="padding-left:2.5rem;" placeholder="Faça a sua busca..." value="<?= htmlspecialchars($search) ?>">
    </form>
  </div>

  <?php if ($tab === 'services'): ?>
    <div class="category-bar">
      <?php
      $cats = [
        ['id' => 'all', 'label' => 'Todos', 'icon' => '✨'],
        ['id' => 'cabelo', 'label' => 'Cabelo', 'icon' => '✂️'],
        ['id' => 'barba', 'label' => 'Barba', 'icon' => '🪒'],
        ['id' => 'combo', 'label' => 'Combos', 'icon' => '👑'],
        ['id' => 'extras', 'label' => 'Extras', 'icon' => '💎'],
      ];
      foreach ($cats as $cat):
      ?>
        <a href="?tab=services&category=<?= $cat['id'] ?>&search=<?= urlencode($search) ?>" class="cat-btn <?= $category === $cat['id'] ? 'active' : '' ?>">
          <span><?= $cat['icon'] ?></span> <?= $cat['label'] ?>
        </a>
      <?php endforeach; ?>
    </div>

    <div class="section-label"><span>✂</span> FAÇA SUA RESERVA</div>

    <?php if (empty($filtered)): ?>
      <div class="glass-card" style="padding:2rem;text-align:center;">
        <p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum serviço encontrado.</p>
      </div>
    <?php else: ?>
      <?php foreach ($filtered as $s): ?>
        <div class="service-card">
          <div class="service-overlay" style="position:relative;">
            <?php if (!empty($s['image_url']) && !str_starts_with($s['image_url'], 'stock://')): ?>
              <img src="<?= htmlspecialchars($s['image_url']) ?>" alt="<?= htmlspecialchars($s['title']) ?>" class="service-img">
            <?php else: ?>
              <div class="service-img-placeholder">✂</div>
            <?php endif; ?>
            <span class="service-duration">🕐 <?= htmlspecialchars($s['duration']) ?></span>
          </div>
          <div class="service-body">
            <div class="service-title"><?= htmlspecialchars($s['title']) ?></div>
            <div class="service-subtitle"><?= htmlspecialchars($s['subtitle'] ?? '') ?></div>
            <div class="service-footer">
              <span class="service-price gold-text">R$ <?= number_format($s['price'], 2, ',', '.') ?></span>
              <a href="booking.php?service_id=<?= $s['id'] ?>" class="service-book-btn">Agendar Aqui →</a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>

  <?php else: ?>
    <div class="section-label"><span>🛍</span> Nossos Produtos</div>

    <?php if (empty($products)): ?>
      <div class="glass-card" style="padding:2rem;text-align:center;">
        <p style="font-size:0.875rem;color:var(--muted-foreground);">Nenhum produto encontrado.</p>
      </div>
    <?php else: ?>
      <?php foreach ($products as $p): ?>
        <div class="service-card">
          <?php if (!empty($p['image_url'])): ?>
            <img src="<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['title']) ?>" class="service-img">
          <?php else: ?>
            <div class="service-img-placeholder">🛍</div>
          <?php endif; ?>
          <div class="service-body">
            <div class="service-title"><?= htmlspecialchars($p['title']) ?></div>
            <div class="service-subtitle"><?= htmlspecialchars($p['description'] ?? '') ?></div>
            <div class="service-footer">
              <span class="service-price gold-text">R$ <?= number_format($p['price'], 2, ',', '.') ?></span>
              <button class="btn-accent" style="font-size:0.75rem;padding:0.5rem 1rem;">➕ Adicionar</button>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  <?php endif; ?>
</main>
<?php require 'includes/footer.php'; ?>
