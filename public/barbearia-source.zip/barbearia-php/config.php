<?php
// Supabase Configuration
define('SUPABASE_URL', 'YOUR_SUPABASE_URL');
define('SUPABASE_KEY', 'YOUR_SUPABASE_ANON_KEY');
define('SUPABASE_SERVICE_KEY', 'YOUR_SERVICE_ROLE_KEY');

session_start();

function supabase_request($endpoint, $method = 'GET', $data = null, $token = null) {
    $url = SUPABASE_URL . '/rest/v1/' . $endpoint;
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . SUPABASE_KEY,
        'Authorization: Bearer ' . ($token ?: SUPABASE_KEY),
    ];
    if ($method === 'GET' || $method === 'DELETE') {
        $headers[] = 'Prefer: return=representation';
    }
    if ($method === 'POST' || $method === 'PATCH') {
        $headers[] = 'Prefer: return=representation';
    }
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($data) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['data' => json_decode($response, true), 'status' => $httpCode];
}

function supabase_auth($endpoint, $data) {
    $url = SUPABASE_URL . '/auth/v1/' . $endpoint;
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . SUPABASE_KEY,
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function is_admin() {
    return isset($_SESSION['admin_token']) && !empty($_SESSION['admin_token']);
}

function get_settings() {
    $result = supabase_request('business_settings?select=key,value');
    $settings = [];
    if ($result['data']) {
        foreach ($result['data'] as $row) {
            $settings[$row['key']] = $row['value'] ?? '';
        }
    }
    return $settings;
}
?>