# Barbearia PHP

Clone completo do sistema de barbearia em PHP/HTML.

## Requisitos
- PHP 7.4+
- curl extension
- Supabase project

## Configuração
1. Edite `config.php` com suas credenciais do Supabase:
   - `SUPABASE_URL` - URL do seu projeto
   - `SUPABASE_KEY` - Chave anon do Supabase
   - `SUPABASE_SERVICE_KEY` - Chave service_role (para admin)

2. Coloque os arquivos em um servidor PHP (XAMPP, Apache, Nginx etc.)

3. Acesse `/admin/login.php` para o painel admin

## Estrutura
```
├── index.php          # Página principal (serviços + loja)
├── booking.php        # Agendamento
├── config.php         # Configuração Supabase
├── assets/style.css   # CSS completo
├── includes/          # Headers e footers
├── admin/
│   ├── login.php      # Login admin
│   ├── index.php      # Dashboard
│   ├── services.php   # Gerenciar serviços
│   ├── barbers.php    # Gerenciar barbeiros
│   ├── appointments.php # Agendamentos
│   ├── coupons.php    # Cupons
│   ├── store.php      # Loja (produtos + pedidos + config)
│   ├── prize_wheel.php # Roleta premiada
│   ├── settings.php   # Configurações gerais
│   └── logout.php     # Logout
└── README.md
```
