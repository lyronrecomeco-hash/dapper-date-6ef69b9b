<?php
require_once __DIR__ . '/../config.php';
if (!is_admin()) { header('Location: login.php'); exit; }
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$navItems = [
  ['label' => 'Dashboard', 'page' => 'index', 'icon' => '📊'],
  ['label' => 'Serviços', 'page' => 'services', 'icon' => '✂'],
  ['label' => 'Loja', 'page' => 'store', 'icon' => '🛍'],
  ['label' => 'Barbeiros', 'page' => 'barbers', 'icon' => '👤'],
  ['label' => 'Agendamentos', 'page' => 'appointments', 'icon' => '📅'],
  ['label' => 'Cupons', 'page' => 'coupons', 'icon' => '🏷'],
  ['label' => 'Roleta', 'page' => 'prize_wheel', 'icon' => '🎁'],
  ['label' => 'Configurações', 'page' => 'settings', 'icon' => '⚙'],
];
$greeting = '';
$hour = (int)date('H');
if ($hour >= 5 && $hour < 12) $greeting = 'Bom dia';
elseif ($hour >= 12 && $hour < 18) $greeting = 'Boa tarde';
elseif ($hour >= 18) $greeting = 'Boa noite';
else $greeting = 'Boa madrugada';
$pageTitle = $currentPage === 'index' ? "$greeting, Admin." : '';
foreach ($navItems as $item) { if ($item['page'] === $currentPage) { $pageTitle = $pageTitle ?: $item['label']; break; } }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - <?= htmlspecialchars($pageTitle) ?></title>
  <link rel="stylesheet" href="../assets/style.css">
</head>
<body style="background:hsl(230,20%,5%);">
<div class="admin-layout">
  <aside class="admin-sidebar" id="sidebar">
    <div class="sidebar-header">
      <div class="sidebar-brand">
        <div class="sidebar-logo">✂</div>
        <span class="sidebar-title">Admin Panel</span>
      </div>
      <button onclick="document.getElementById('sidebar').classList.remove('open')" class="modal-close hide-desktop" style="display:none;">✕</button>
    </div>
    <nav class="sidebar-nav">
      <?php foreach ($navItems as $item): ?>
        <a href="<?= $item['page'] ?>.php" class="<?= $currentPage === $item['page'] ? 'active' : '' ?>">
          <span><?= $item['icon'] ?></span>
          <?= $item['label'] ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="sidebar-footer">
      <a href="logout.php">🚪 Sair</a>
    </div>
  </aside>
  <div class="admin-main">
    <header class="admin-header">
      <button class="menu-toggle btn-ghost" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
      <h1><?= htmlspecialchars($pageTitle) ?></h1>
    </header>
    <main class="admin-content">