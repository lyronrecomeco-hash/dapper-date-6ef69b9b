<?php require_once __DIR__ . '/../config.php'; $settings = get_settings(); $businessName = $settings['business_name'] ?? 'Barbearia'; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($businessName) ?></title>
  <link rel="stylesheet" href="assets/style.css">
  <link href="https://unpkg.com/lucide-static@latest/font/lucide.min.css" rel="stylesheet">
</head>
<body>
<header class="site-header">
  <div class="header-inner">
    <div class="header-brand">
      <div class="header-logo">✂</div>
      <div>
        <div class="header-title"><?= htmlspecialchars($businessName) ?></div>
        <div class="header-sub">Premium Grooming</div>
      </div>
    </div>
  </div>
</header>